﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using UnitTestDemo.Models;

namespace UnitTestDemo.Databases
{
    public class CardDatabase : DbContext
    {
        public CardDatabase()
            : base("CardDatabase")
        {
            Database.SetInitializer<CardDatabase>(new DropCreateDatabaseAlways<CardDatabase>());
        }

        public System.Data.Entity.DbSet<UnitTestDemo.Models.OrderModels> CardRegistrationModels { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<OrderModels>()
                .Property(u => u.FirstName)
                .HasColumnName("FirstName");
        } 
    }
}