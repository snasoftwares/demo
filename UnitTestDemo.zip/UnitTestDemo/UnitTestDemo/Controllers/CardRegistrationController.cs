﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnitTestDemo.Models;
using UnitTestDemo.Databases;

namespace UnitTestDemo.Controllers
{
    public class CardRegistrationController : Controller
    {
        private CardDatabase db = new CardDatabase();

        // GET: /CardRegistration/
        public ActionResult Index()
        {
            return View(db.CardRegistrationModels.ToList());
        }

        // GET: /CardRegistration/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderModels cardregistrationmodels = db.CardRegistrationModels.Find(id);
            if (cardregistrationmodels == null)
            {
                return HttpNotFound();
            }
            return View(cardregistrationmodels);
        }

        // GET: /CardRegistration/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /CardRegistration/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProcessOrder([Bind(Include = "Id,FirstName,LastName,Address,City,State,Zip,Phone,Email,CardNumber,CardExpirationMonth,CardExpirationYear,CardSecurityCode,ProductId,Price")] OrderModels cardregistrationmodels)
        {
            if (ModelState.IsValid)
            {
                if((DateTime.Now.Month>cardregistrationmodels.CardExpirationMonth && DateTime.Now.Year>cardregistrationmodels.CardExpirationYear) || 
                        (DateTime.Now.Year==cardregistrationmodels.CardExpirationYear && DateTime.Now.Month>cardregistrationmodels.CardExpirationMonth))
                {
                    cardregistrationmodels.status=2;
                }
                else
                {
                    cardregistrationmodels.status=1;
                }
                db.CardRegistrationModels.Add(cardregistrationmodels);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(cardregistrationmodels);
        }

        // GET: /CardRegistration/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderModels cardregistrationmodels = db.CardRegistrationModels.Find(id);
            if (cardregistrationmodels == null)
            {
                return HttpNotFound();
            }
            return View(cardregistrationmodels);
        }

        // POST: /CardRegistration/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,FirstName,LastName,Address,City,State,Zip,Phone,Email,CardNumber,CardExpirationMonth,CardExpirationYear,CardSecurityCode,ProductId,Price")] OrderModels cardregistrationmodels)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cardregistrationmodels).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cardregistrationmodels);
        }

        // GET: /CardRegistration/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderModels cardregistrationmodels = db.CardRegistrationModels.Find(id);
            if (cardregistrationmodels == null)
            {
                return HttpNotFound();
            }
            return View(cardregistrationmodels);
        }

        // POST: /CardRegistration/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            OrderModels cardregistrationmodels = db.CardRegistrationModels.Find(id);
            db.CardRegistrationModels.Remove(cardregistrationmodels);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
