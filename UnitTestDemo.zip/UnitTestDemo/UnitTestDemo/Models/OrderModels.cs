﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UnitTestDemo.Models
{
    public class OrderModels
    {
        public OrderModels()
        { }

        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "FirstName is required.")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "LastName is required.")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Address is required.")]
        public string Address { get; set; }
        [Required(ErrorMessage = "City is required.")]
        public string City { get; set; }
        [Required(ErrorMessage = "State is required.")]
        public string State { get; set; }
        [Required(ErrorMessage = "Zip code is required.")]
        [DataType(DataType.PostalCode)]
        public int Zip { get; set; }
        [Required(ErrorMessage = "Phone number is required.")]
        [DataType(DataType.PhoneNumber)]
        public int Phone { get; set; }
        [Required(ErrorMessage = "EmailId is required.")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required(ErrorMessage = "CardNumber is required.")]
        public int CardNumber { get; set; }        
        [Required(ErrorMessage = "CardExpirationMonth is required.")]
        public int CardExpirationMonth { get; set; }
        [Required(ErrorMessage = "CardExpirationYear is required.")]        
        public int CardExpirationYear { get; set; }
        [Required(ErrorMessage = "CardSecurityCode is required.")]
        public string CardSecurityCode { get; set; }
        [Required(ErrorMessage = "ProductId is required.")]
        public int ProductId { get; set; }
        [Required(ErrorMessage = "Price is required.")]
        public decimal Price { get; set; }
        public int status { get; set; }
    }
}